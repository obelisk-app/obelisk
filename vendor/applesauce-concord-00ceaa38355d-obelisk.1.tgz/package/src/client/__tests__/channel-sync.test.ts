// D-04 backward re-read pass (ROTATE-06, channel scope): `syncChannelEpochs`
// walks `channel.held` oldest-first, re-invoking `syncRekeyAndAdvance` against
// each held epoch's rekey plane; a late-arriving strictly-lower sibling for a
// PAST channel epoch discards the forward continuation and re-walks forward
// from the corrected key. Exercised directly against `syncChannelEpochs` over a
// dependency-injected pool that SERVES pre-built wraps (no sockets, no
// ConcordPrivateChannel) — mirrors client/__tests__/sync.test.ts's pattern.

import { describe, it } from "@std/testing/bdd";
import { expect } from "@std/expect";
import { BehaviorSubject, EMPTY, from, NEVER, Subject } from "rxjs";
import { generateSecretKey } from "applesauce-core/helpers/keys";
import { PrivateKeySigner } from "applesauce-signers";
import { type Debugger, EventStore, logger } from "applesauce-core";
import { bytesToHex } from "@noble/hashes/utils.js";
import type { NostrEvent } from "applesauce-core/helpers/event";
import type { RelayPool } from "applesauce-relay";

import { StreamSigners } from "../auth.ts";
import { createCommunity } from "../../helpers/community.ts";
import { getWrapSeal } from "../../helpers/gift-wrap.ts";
import { buildChannelRekey, deriveChannelKeys } from "../../helpers/keys.ts";
import { wrapSeal } from "../../operations/gift-wrap.ts";

import type { ChannelKey } from "../../types.ts";
import { type ChannelSyncContext, syncChannelEpochs } from "../channel-sync.ts";

// Same servingPool shape as client/__tests__/sync.test.ts and
// e2e/private-channel.test.ts.
function servingPool(events: NostrEvent[]): RelayPool {
  const relay = {
    url: "wss://fake",
    challenge: null,
    challenge$: new BehaviorSubject<string | null>(null),
    isAuthenticated: () => false,
    authenticate: async () => ({ ok: true }),
    getSupported: async () => null,
    sync: () => EMPTY,
    request: (filters: unknown) => {
      const fs = (Array.isArray(filters) ? filters : [filters]) as Array<{
        kinds?: number[];
        authors?: string[];
        since?: number;
        until?: number;
      }>;
      const match = events.filter((e) =>
        fs.some(
          (f) =>
            (!f.kinds || f.kinds.includes(e.kind)) &&
            (!f.authors || f.authors.includes(e.pubkey)) &&
            (f.since === undefined || e.created_at >= f.since) &&
            (f.until === undefined || e.created_at <= f.until),
        )
      );
      return from(match);
    },
  };
  return {
    status$: new Subject(),
    relay: () => relay,
    subscription: () => NEVER,
    request: (_relays: string[], filters: unknown) => relay.request(filters),
    publish: async () => [],
  } as unknown as RelayPool;
}

describe("syncChannelEpochs — D-04 backward re-read spine (ROTATE-06, channel scope)", () => {
  it("heals a held epoch to a late-arriving strictly-lower sibling and rebuilds N+2 from it", async () => {
    const rotatorA = new PrivateKeySigner(generateSecretKey());
    const rotatorAPub = await rotatorA.getPublicKey();
    const rotatorB = new PrivateKeySigner(generateSecretKey());
    const rotatorBPub = await rotatorB.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();

    const genesis = await createCommunity({ ownerPubkey: rotatorAPub, name: "T", relays: ["wss://fake"] });
    const material = genesis.material;

    const channelId = bytesToHex(generateSecretKey());
    const epoch1Key = bytesToHex(generateSecretKey());
    const channelAtEpoch1: ChannelKey = { id: channelId, key: epoch1Key, epoch: 1, name: "secret" };

    // HAND-DERIVED ordering (CORD-06 §3's lowest-key-wins rule) — fixed byte
    // patterns, not random keys, so "LOW < HIGH" holds by construction:
    const lowKey = new Uint8Array(32).fill(0x01);
    const highKey = new Uint8Array(32).fill(0xff);
    expect(bytesToHex(lowKey) < bytesToHex(highKey)).toBe(true); // sanity-check the hand derivation itself

    const recipients = [rotatorAPub, rotatorBPub, selfPub];

    // rotatorA's rotation (HIGH) is what the walk originally adopted for epoch
    // 1→2 — the channel is already sitting at epoch 2 (HIGH), epoch 1 held.
    const highPlan = await buildChannelRekey(material, channelAtEpoch1, rotatorA, {
      recipients,
      self: rotatorAPub,
      newKey: highKey,
    });
    const events: NostrEvent[] = [...highPlan.rekeyWraps];

    // rotatorB's competing rotation (LOW) for the SAME epoch 1→2 slot arrives
    // LATE — appended to the relay only now.
    const lowPlan = await buildChannelRekey(material, channelAtEpoch1, rotatorB, {
      recipients,
      self: rotatorBPub,
      newKey: lowKey,
    });
    events.push(...lowPlan.rekeyWraps);

    // A legitimate epoch2(LOW)→epoch3 rotation, minted directly off the
    // CORRECTED LOW key — proves the cascade rebuilds N+2 from the corrected
    // N+1, not the abandoned HIGH branch. Addressed under the LOW channel key's
    // OWN epoch-2 rekey listen address (channel-rekey addresses key on the
    // COMMUNITY root, not the channel key itself, so this event is visible
    // regardless of which channel-key branch wins — the walk just can't reach
    // it until it actually advances to epoch 2).
    const channelAtEpoch2Low: ChannelKey = { id: channelId, key: bytesToHex(lowKey), epoch: 2, name: "secret" };
    const epoch3Key = generateSecretKey();
    const followupPlan = await buildChannelRekey(material, channelAtEpoch2Low, rotatorA, {
      recipients,
      self: rotatorAPub,
      newKey: epoch3Key,
    });
    events.push(...followupPlan.rekeyWraps);

    const pool = servingPool(events);
    // D-41: the test owns the context's store and disposes it.
    const store = new EventStore();
    const ctx: ChannelSyncContext = {
      pool,
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      material,
      isAuthorized: (r) => r === rotatorAPub || r === rotatorBPub,
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };

    try {
      // The channel walk STARTS already at epoch 2 (HIGH), epoch 1 held — as if a
      // prior full sync had already adopted the HIGH branch, exactly like
      // client/__tests__/sync.test.ts's root-scope cascade oracle.
      const channelAtEpoch2High: ChannelKey = {
        id: channelId,
        key: bytesToHex(highKey),
        epoch: 2,
        name: "secret",
        held: [{ epoch: 1, key: epoch1Key }],
      };

      const result = await syncChannelEpochs(ctx, channelAtEpoch2High);
      expect(result.removed).toBe(false);

      // N+2 rebuilt from the CORRECTED N+1 — the tip is epoch 3, minted off LOW.
      expect(result.tipKey?.epoch).toBe(3);
      expect(result.tipKey?.key).toBe(bytesToHex(epoch3Key));
      // held threads through the corrected branch (LOW at epoch 2, the original
      // epoch 1 key underneath it), proving the abandoned HIGH branch at epoch 2
      // is fully discarded, not merely skipped over.
      expect(result.tipKey?.held).toEqual([
        { epoch: 2, key: bytesToHex(lowKey) },
        { epoch: 1, key: epoch1Key },
      ]);
    } finally {
      store.dispose();
    }
  });

  it("re-reading a held epoch with no strictly-lower sibling leaves the chain untouched", async () => {
    const rotatorA = new PrivateKeySigner(generateSecretKey());
    const rotatorAPub = await rotatorA.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();

    const genesis = await createCommunity({ ownerPubkey: rotatorAPub, name: "T", relays: ["wss://fake"] });
    const material = genesis.material;

    const channelId = bytesToHex(generateSecretKey());
    const epoch1Key = bytesToHex(generateSecretKey());
    const channelAtEpoch1: ChannelKey = { id: channelId, key: epoch1Key, epoch: 1, name: "secret" };

    const highKey = new Uint8Array(32).fill(0xff);
    const recipients = [rotatorAPub, selfPub];
    const highPlan = await buildChannelRekey(material, channelAtEpoch1, rotatorA, {
      recipients,
      self: rotatorAPub,
      newKey: highKey,
    });

    const pool = servingPool([...highPlan.rekeyWraps]);
    const store = new EventStore();
    const ctx: ChannelSyncContext = {
      pool,
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      material,
      isAuthorized: (r) => r === rotatorAPub,
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };

    try {
      const channelAtEpoch2: ChannelKey = {
        id: channelId,
        key: bytesToHex(highKey),
        epoch: 2,
        name: "secret",
        held: [{ epoch: 1, key: epoch1Key }],
      };

      // Only the already-adopted (HIGH) rotation is on the relay — re-reading it
      // rediscovers the SAME key, which is not strictly lower, so the tip and the
      // held history are unchanged.
      const result = await syncChannelEpochs(ctx, channelAtEpoch2);
      expect(result.removed).toBe(false);
      expect(result.tipKey?.epoch).toBe(2);
      expect(result.tipKey?.key).toBe(bytesToHex(highKey));
      expect(result.tipKey?.held).toEqual([{ epoch: 1, key: epoch1Key }]);
    } finally {
      store.dispose();
    }
  });

  it("a channel rekey under a past outer tag is not adopted by the walk, as live receive drops it (D-22)", async () => {
    const rotator = new PrivateKeySigner(generateSecretKey());
    const rotatorPub = await rotator.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();
    const genesis = await createCommunity({ ownerPubkey: rotatorPub, name: "T", relays: ["wss://fake"] });
    const material = genesis.material;
    const channelId = bytesToHex(generateSecretKey());
    const channelAtEpoch1: ChannelKey = {
      id: channelId,
      key: bytesToHex(generateSecretKey()),
      epoch: 1,
      name: "secret",
    };
    const plan = await buildChannelRekey(material, channelAtEpoch1, rotator, {
      recipients: [rotatorPub, selfPub],
      self: rotatorPub,
    });
    // Rewrap each rekey seal under the same rekey address with a past outer tag, as any holder of that address can.
    const rekeyKeys = new Map(deriveChannelKeys(material, channelAtEpoch1).nextRekey.map((r) => [r.key.pk, r.key]));
    const rewrapped: NostrEvent[] = [];
    for (const wrap of plan.rekeyWraps) {
      const key = rekeyKeys.get(wrap.pubkey)!;
      rewrapped.push(await wrapSeal(key.sk, key.convKey, { expiration: 1 })(getWrapSeal(wrap, key.convKey)!));
    }
    expect(rewrapped.length).toBeGreaterThan(0);
    const store = new EventStore();
    const ctx: ChannelSyncContext = {
      pool: servingPool(rewrapped),
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      material,
      isAuthorized: (r) => r === rotatorPub,
      logger: logger.extend("test"),
      decodeLogger: logger.extend("test").extend("decode"),
    };
    try {
      const result = await syncChannelEpochs(ctx, channelAtEpoch1);
      // Non-vacuity: without plane info the outer-tag fallback returns the refused rekey and the walk adopts epoch 2.
      expect(result.removed).toBe(false);
      expect(result.tipKey?.epoch).toBe(1);
    } finally {
      store.dispose();
    }
  });

  // Non-vacuity: the litmus line counted only wraps returned by the batch, which refuses wraps at the loader boundary,
  // so it read `fetched=0 dropped=0`. Each drop is logged once, with the rekey address's own epoch as live receive does.
  it("the rekey litmus line counts the wraps the loader refused, each logged once with its plane's epoch (D-05)", async () => {
    const rotator = new PrivateKeySigner(generateSecretKey());
    const rotatorPub = await rotator.getPublicKey();
    const self = new PrivateKeySigner(generateSecretKey());
    const selfPub = await self.getPublicKey();
    const genesis = await createCommunity({ ownerPubkey: rotatorPub, name: "T", relays: ["wss://fake"] });
    const material = genesis.material;
    const channelAtEpoch1: ChannelKey = {
      id: bytesToHex(generateSecretKey()),
      key: bytesToHex(generateSecretKey()),
      epoch: 1,
      name: "secret",
    };
    const plan = await buildChannelRekey(material, channelAtEpoch1, rotator, {
      recipients: [rotatorPub, selfPub],
      self: rotatorPub,
    });
    const rekeyKeys = new Map(deriveChannelKeys(material, channelAtEpoch1).nextRekey.map((r) => [r.key.pk, r.key]));
    const rewrapped: NostrEvent[] = [];
    for (const wrap of plan.rekeyWraps) {
      const key = rekeyKeys.get(wrap.pubkey)!;
      rewrapped.push(await wrapSeal(key.sk, key.convKey, { expiration: 1 })(getWrapSeal(wrap, key.convKey)!));
    }
    expect(rewrapped.length).toBeGreaterThan(0);
    const lines: unknown[][] = [];
    const record = (prefix: string): Debugger => {
      const log = Object.assign((...args: unknown[]) => void lines.push([prefix, ...args]), {
        extend: () => log,
        enabled: true,
      });
      return log as unknown as Debugger;
    };
    const store = new EventStore();
    const ctx: ChannelSyncContext = {
      pool: servingPool(rewrapped),
      signers: new StreamSigners(),
      eventStore: store,
      signer: self,
      self: selfPub,
      relays: ["wss://fake"],
      route: () => {},
      onAuthRequired: () => {},
      material,
      isAuthorized: (r) => r === rotatorPub,
      logger: record("sync"),
      decodeLogger: record("decode"),
    };
    try {
      await syncChannelEpochs(ctx, channelAtEpoch1);
      const litmus = lines.filter(([, format]) => String(format).startsWith("rekey plane"));
      expect(litmus).toHaveLength(1);
      // from_epoch, to_epoch, fetched, decoded, dropped, skipped.
      expect(litmus[0].slice(2)).toEqual([1, 2, rewrapped.length, 0, rewrapped.length, 0]);
      const drops = lines.filter(([prefix, format]) => prefix === "decode" && String(format).startsWith("dropped"));
      expect(drops).toHaveLength(rewrapped.length);
      for (const drop of drops) expect(drop.slice(3)).toEqual(["rekey", 2]);
    } finally {
      store.dispose();
    }
  });
});
